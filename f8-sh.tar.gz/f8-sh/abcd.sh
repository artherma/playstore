#!/bin/bash
echo "asdfas;djk"
for i in {1..100}
do
	echo "asdfsadf"
	sleep 10s
done;
