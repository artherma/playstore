#!/bin/bash
#sh ./abcd.sh
#shName="./abcd.sh"
dir="/root/curlDir/f8-sh/"
for i in {e..t}
do
	
	tmpName=$dir"test-"$i".sh"
	#echo $tmpName
#	sh $shName

#开始执行脚本
	sh $tmpName
done;

